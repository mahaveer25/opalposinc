import 'package:flutter/material.dart';
import 'package:opalsystem/model/TaxModel.dart';
import 'package:opalsystem/model/TotalDiscountModel.dart';

import 'package:presentation_displays/secondary_display.dart';

import '../model/product.dart';

class CustomerScreen extends StatefulWidget {
  const CustomerScreen({super.key});

  @override
  _CustomerScreenState createState() => _CustomerScreenState();
}

class _CustomerScreenState extends State<CustomerScreen> {
  List<Product> list = [];

  String? price, tax, payable;
  TotalDiscountModel? discount;
  TaxModel? taxModel;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return homeCustomer(cartList: list);
  }

  Widget homeCustomer({required List<Product> cartList}) {
    final totalitems = list.length.toString();
    double calculateItemTotal() {
      double itemTotal = 0.0;

      itemTotal = cartList
          .map((product) {
            return double.parse(product.calculate.toString()) *
                double.parse(product.quantity.toString());
          })
          .toList()
          .fold(0.0, (previousValue, element) => previousValue + element)
          .toDouble();

      if (discount?.amount != null) {
        if (discount?.type == "Percentage") {
          itemTotal = itemTotal - (itemTotal * ((discount?.amount ?? 0) / 100));

          return itemTotal;
        } else if (discount?.type == "Fixed") {
          itemTotal = (itemTotal - discount!.amount!.toDouble());

          return itemTotal;
        } else {
          return itemTotal;
        }
      } else {
        return itemTotal;
      }
    }

    double totalWithTax() {
      double total = calculateItemTotal();
      double taxRate = taxModel?.amount == null
          ? 0.0
          : double.parse(taxModel!.amount.toString()) / 100;

      double taxAmount = total * taxRate;
      double totalWithTax = total + taxAmount;

      return totalWithTax;
    }

    return Scaffold(
        body: SecondaryDisplay(
      callback: (dynamic argument) {
        if (argument['type'] == 'add') {
          Product product = Product.fromJson(argument['product']);

          Product selected = list.firstWhere(
              (element) => element.variationId == product.variationId,
              orElse: () => Product());

          if (selected.productId == null) {
            setState(() {
              list.add(product);
            });
          } else {
            setState(() {
              selected.quantity = product.quantity;
              selected.lineDiscountType = product.lineDiscountType;
              selected.lineDiscountAmount = product.lineDiscountAmount;
            });
          }
        } else if (argument['type'] == 'remove') {
          Product product = Product.fromJson(argument['product']);

          setState(() {
            list.removeWhere(
                (element) => element.variationId == product.variationId);
          });
        } else if (argument['type'] == 'delete') {
          setState(() {
            list.clear();
          });
        } else if (argument['type'] == 'update') {
          setState(() {
            Product product = Product.fromJson(argument['product']);
            // log('got product in second screen ${product.toJson()}');

            Product selected = list
                .where((element) => element.variationId == product.variationId)
                .single;

            selected.calculate = product.calculate;
            selected.unit_price = product.unit_price;
            selected.quantity = product.quantity;
            selected.lineDiscountType = product.lineDiscountType;
            selected.lineDiscountAmount = product.lineDiscountAmount;

            // log('to update product ${selected.toJson()}');
          });
        } else if (argument['type'] == 'discount') {
          final discountPrice =
              TotalDiscountModel.fromJson(argument['discount']);

          setState(() {
            discount = discountPrice;
          });
        } else if (argument['type'] == 'tax') {
          final tax = TaxModel.fromJson(argument['tax']);

          setState(() {
            taxModel = tax;
          });
        }
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(
            height: 5,
          ),
          const Padding(
              padding: EdgeInsets.symmetric(horizontal: 10.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Customer Display",
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: Colors.purple,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              )),
          Expanded(child: cartListView(cartList: cartList)),
          Padding(
            padding:
                const EdgeInsets.only(left: 10.0, right: 10.0, bottom: 10.0),
            child: SizedBox(
              height: 80,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Column(
                        children: [
                          Text(
                            'Total Items',
                            style: TextStyle(
                                fontSize: 10, fontWeight: FontWeight.bold),
                          )
                        ],
                      ),
                      Column(
                        children: [
                          Text(totalitems,
                              style: const TextStyle(
                                  fontSize: 10, fontWeight: FontWeight.bold))
                        ],
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Column(
                        children: [
                          Text('Sub Total',
                              style: TextStyle(
                                  fontSize: 10, fontWeight: FontWeight.bold))
                        ],
                      ),
                      Column(
                        children: [
                          Text(calculateItemTotal().toStringAsFixed(2),
                              style: const TextStyle(
                                  fontSize: 10, fontWeight: FontWeight.bold))
                        ],
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Column(
                        children: [
                          Text('Discount',
                              style: TextStyle(
                                  fontSize: 10, fontWeight: FontWeight.bold))
                        ],
                      ),
                      Column(
                        children: [
                          Text(
                              discount?.amount == null
                                  ? 0.0.toString()
                                  : discount!.amount.toString(),
                              style: const TextStyle(
                                  fontSize: 10, fontWeight: FontWeight.bold))
                        ],
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Column(
                        children: [
                          Text('Tax',
                              style: TextStyle(
                                  fontSize: 10, fontWeight: FontWeight.bold))
                        ],
                      ),
                      Column(
                        children: [
                          Text(
                              double.parse(taxModel?.amount ??
                                      0.0.toStringAsFixed(2))
                                  .toStringAsFixed(2),
                              style: const TextStyle(
                                  fontSize: 10, fontWeight: FontWeight.bold))
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Center(
                        child: Column(
                          children: [
                            Text(
                              'Total Payable: \$${totalWithTax().toStringAsFixed(2)}',
                              style: const TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.purple),
                              textAlign: TextAlign.center,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ));
  }

  Widget cartListView({required List<Product> cartList}) {
    return ListView.separated(
      itemCount: cartList.length,
      separatorBuilder: (BuildContext context, int index) => const Divider(),
      itemBuilder: (context, index) {
        final Product product = cartList.reversed.toList()[index];
        final quantity = double.parse(product.quantity.toString());

        return ListTile(
          dense: true,
          onTap: () {},
          leading: Image.network(
            product.image.toString(),
            fit: BoxFit.cover,
          ),
          title: Text(
            product.name.toString(),
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: Color.fromARGB(255, 0, 0, 0),
            ),
          ),
          subtitle: Row(
            children: <Widget>[
              Text(
                '\$${(double.parse(product.calculate.toString()) * quantity.toInt()).toStringAsFixed(2)}',
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  color: Colors.orange,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // Widget cartBlocBuilder() {
  //   return BlocBuilder(builder: (context, state) {
  //     if (state is CartCustomerLoadedState) {
  //       return homeCustomer(cartList: state.listProduct);
  //     }
  //
  //     return Container();
  //   });
  // }
  //
  // Widget cartBloc() {
  //   final dbHelper = DatabaseHelper();
  //
  //   return FutureBuilder(
  //       future: dbHelper.getModels(),
  //       builder: (context, snapshot) {
  //         if (!snapshot.hasData) {
  //           return homeCustomer(cartList: []);
  //         }
  //         log('customer display cart in snapshot ${snapshot.data!}');
  //
  //         return homeCustomer(cartList: list);
  //       });
  // }
}
